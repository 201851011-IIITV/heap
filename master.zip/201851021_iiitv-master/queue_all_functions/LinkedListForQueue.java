public class LinkedListForQueue<D> {
    D value;
    LinkedListForQueue<D> node;
    LinkedListForQueue(D value){
        node=null;
        this.value=value;

    }
}
