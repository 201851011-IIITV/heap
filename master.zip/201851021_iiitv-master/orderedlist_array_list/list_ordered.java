public interface list_ordered<D> {
    void add(D obj );
    void remove(Integer i);
    Object search(D i);
    void transverse();
}
