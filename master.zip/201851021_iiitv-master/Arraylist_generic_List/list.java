interface list<D> {
    void add(D obj );
    void add(D obj,Integer i);
    void remove(Integer i);
    void search(D i);
    void transverse();

}
