interface List_Interface<D> {
    void add(D object);
    void add(D object ,Integer pos);
    void remove(Integer pos);
    void transverse();
    void search(D object);
    void sizeof();
    void reverse();
    void getElementat(Integer pos);

}
